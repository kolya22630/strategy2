#include "zip_compressor.h"

Zip_Compressor::Zip_Compressor()
{

}

void Zip_Compressor::compress(){
    std::cout<<"Zip compression";
}
