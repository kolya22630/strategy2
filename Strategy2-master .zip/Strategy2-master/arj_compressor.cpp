#include "arj_compressor.h"


Arj_Compressor::Arj_Compressor()
{

}

void Arj_Compressor::compress(){
    std::cout<<"Arj compression";
}
