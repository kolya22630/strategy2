#ifndef RAR__COMPRESSOR_H
#define RAR__COMPRESSOR_H


class Rar__Compressor
{
public:
    Rar__Compressor();
};

#endif // RAR__COMPRESSOR_H
