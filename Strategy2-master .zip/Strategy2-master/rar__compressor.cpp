#include "rar__compressor.h"

Rar__Compressor::Rar__Compressor()
{

}
