#include "rar_compressor.h"

Rar_Compressor::Rar_Compressor()
{

}

void Rar_Compressor::compress(){
    std::cout<<"Rar compression";
}
