#include "compression.h"

Compression::Compression()
{

}

Compression::~Compression()
{

}


